Blockly.Msg.BLOCK_AIOT_DHT_MEANSURE_MESSAGE0 = "%1 update DHT20 temperature & humidity sensor"
Blockly.Msg.BLOCK_AIOT_DHT_MEANSURE_TOOLTIP = "Update the temperature and humidity sensor"
Blockly.Msg.BLOCK_AIOT_DHT_MEANSURE_HELPURL = ""

Blockly.Msg.BLOCK_AIOT_DHT_READ_MESSAGE0 = "%2 read %1 from DHT20 sensor"
Blockly.Msg.BLOCK_AIOT_DHT_READ_MESSAGE1 = "temperature"
Blockly.Msg.BLOCK_AIOT_DHT_READ_MESSAGE2 = "humidity"
Blockly.Msg.BLOCK_AIOT_DHT_READ_TOOLTIP = "Read temperature or humidity from DHT20 temperature and humidity sensor"
Blockly.Msg.BLOCK_AIOT_DHT_READ_HELPURL = ""
