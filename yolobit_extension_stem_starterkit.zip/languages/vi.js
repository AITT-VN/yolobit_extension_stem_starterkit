Blockly.Msg.BLOCK_AIOT_DHT_MEANSURE_MESSAGE0 = "%1 cập nhật cảm biến nhiệt độ & độ ẩm DHT20"
Blockly.Msg.BLOCK_AIOT_DHT_MEANSURE_TOOLTIP = "Cập nhập giá trị nhiệt độ và độ ẩm từ cảm biến nhiệt độ & độ ẩm DHT20"
Blockly.Msg.BLOCK_AIOT_DHT_MEANSURE_HELPURL = ""

Blockly.Msg.BLOCK_AIOT_DHT_READ_MESSAGE0 = "%2 đọc %1 từ cảm biến DHT20"
Blockly.Msg.BLOCK_AIOT_DHT_READ_MESSAGE1 = "nhiệt độ"
Blockly.Msg.BLOCK_AIOT_DHT_READ_MESSAGE2 = "độ ẩm"
Blockly.Msg.BLOCK_AIOT_DHT_READ_TOOLTIP = ""
Blockly.Msg.BLOCK_AIOT_DHT_READ_HELPURL = ""
